# TA-Android
An Android project for skripsi

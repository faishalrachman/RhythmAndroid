package com.faishalrachman.amonsecg.misc;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by maakbar on 11/21/16.
 */

public class ViewHolder extends RecyclerView.ViewHolder{
    public ViewHolder(View itemView) {
        super(itemView);
    }
}
